SuperRes(input, passes, strength, softness, upscalecommand, folder, convert)

Enhances upscaling quality.

Supported video formats: YV12, YV24, RGB24 and RGB32.

Arguments:

passes: How many SuperRes passes to run. Default=1.

strength: How agressively we want to run SuperRes, between 0 and 1. Default=1.

softness: How much smoothness we want to add, between 0 and 1. Default=0.

upscalecommand: An upscaling command that must contain offset-correction. Ex: """nnedi3_rpow2(2, cshift="Spline16Resize")"""

folder: The folder containing .cso files, ending with '/'. Leave empty to use default folder.

convert: Whether to call ConvertToFloat and ConvertFromFloat() within the shader. Set to false if input is already converted. Default=true.





Super-xBR(input, edgeStrength, weight, thirdPass, folder, convert)

Doubles the size of the image. Produces a sharp result, but with severe ringing.

Supported video formats: YV12, YV24, RGB24 and RGB32.

Arguments:

edgeStrength: Value between 0 and 5 specifying the strength. Default=1.

weight: Value between 0 and 1.5 specifying the weight. Default=1.

thirdPass: Whether to run a 3rd pass. Default=true.

folder: The folder containing .cso files, ending with '/'. Leave empty to use default folder.

convert: Whether to call ConvertToFloat and ConvertFromFloat() within the shader. Set to false if input is already converted. Default=true.





Shaders are written by Shiandow and are available here
https://github.com/zachsaw/MPDN_Extensions/

The code was integrated into AviSynth by Etienne Charland.